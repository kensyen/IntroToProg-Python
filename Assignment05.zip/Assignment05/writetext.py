objF = open("C:\\_PythonClass\\Todo.txt", "w")
objF.write("Clean House,low\nPay Bills,high\n")
objF.close()
